$(function(){

   //1:加载头和尾内容
   //加载头文件 header.php
   //加载脚文件 footer.php
   $("#header").load("data/header.php");
   $("#footer").load("data/footer.php");
 
   //模块四:页面加载后，异步请求当前
   //登录用户购物车中商品信息.
   $.ajax({
      url:"data/cart_list.php",
	  data:{uid:10},
	  success:function(data){
       var html = "";
	   for(var i=0;i<data.length;i++){
		   var obj = data[i];
	   html += `
              <tr>
                    <td>
                        <input type="checkbox"/>
                        <input type="hidden" value="${obj.pid}" />
                        <div><img src="${obj.pic}" alt=""/></div>
                    </td>
                    <td><a href="">${obj.pname}</a></td>
                    <td>${obj.price}</td>
                    <td>
                        <button>-</button>
		                <input type="text" value="${obj.count}"/>
		                <button>+</button>
                    </td>
                    <td><span>￥${obj.price*obj.count}</span></td>
                    <td><a href="${obj.id}">删除</a></td>
                </tr>
	   `;
	   }
	   $("#cart tbody").html(html);
	  },
	  error:function(){
	  }
   
   });

    


});