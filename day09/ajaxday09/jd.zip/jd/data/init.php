<?php
$conn = mysqli_connect("127.0.0.1","root","","jd");
$sql = "SET NAMES UTF8";
mysqli_query($conn,$sql);
?>